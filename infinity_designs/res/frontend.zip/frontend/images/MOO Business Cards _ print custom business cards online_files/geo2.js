(function(){
  window['optimizely'] = window['optimizely'] || [];
  window['optimizely'].push(['activateGeoDelayedExperiments', {
    'location':{
      'city': "NAIROBI",
      'continent': "AF",
      'country': "KE",
      'region': ""
    },
    'ip':"105.21.32.22"
  }]);
})
//
()

;